function [l_m l_s2] = estimate_mean_variance_in_log_space(ldat)
% dat = normalized, nonlog data

thres = size(ldat, 2) / 2;

N = size(ldat, 1);

% calculate row means in log space
l_m = [];
l_s2 = [];

for i=1:N
    
    x = ldat(i, :);

    x = x(x > -Inf); % detected entries
    
    %if (var(x) > 0 && length(x) > 2) 
    if (var(x) > 0 && length(x) > thres) 
        l_m = [l_m; mean(x)];
        l_s2 = [l_s2; var(x,1)];
    end
end
