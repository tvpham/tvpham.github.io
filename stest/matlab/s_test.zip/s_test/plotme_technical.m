function [ab, c] = plotme_technical(dat)

[c, mm, ss] = estimate_cv(dat);
c
plot(log(mm), log(ss), '.')
xl = [min([log(mm);log(ss)]) max([log(mm);log(ss)])];
hold on, plot(xl, xl, 'r-', 'LineWidth', 2.5)
plot(xl, xl + log(c), 'g--', 'LineWidth', 2.5)
axis equal, xlim(xl), ylim(xl)
set(gcf, 'Color', 'w')
xlabel('log mean')
ylabel('log standard deviation')

ab = estimate_ab(dat);
figure2_zeros(dat);

function [c, m, s] = estimate_cv(dat)
% dat = normalized, nonlog data

thres = size(dat, 2) / 2;
%thres = 40;

m = [];
s = [];

for i=1:size(dat,1)
    x = dat(i,:);
    if (sum(x > 0) > thres)
        x = x(x > 0);
        m = [m; mean(x)];
        s = [s; std(x, 1)];
    end
end

c = median(s ./ m);

function ab = estimate_ab(dat)
% dat = normalized, nonlog data

N = size(dat, 1);

% calculate row means in log space
m = zeros(N, 1);
for i=1:N
    x = dat(i, :);
    x = x(x>0);
    m(i) = mean(log(x));
end


x = min(m):(max(m)-min(m))/20:max(m);
%x = min(m):(max(m)-min(m))/5:max(m);
n = hist(m, x);


P = [];
for i=1:size(dat,2)
    
    n1 = hist(m(dat(:,i)==0), x);
    
    %c = (n-n1)./n;
    c = n1 ./ n;    
    ok = (c < 1) & (c > 0);        

    p = polyfit(x(ok), log(c(ok)./(1-c(ok))), 1);        
    P = [P; p];    
end

ab = median(P);

function figure2_zeros(dat)

a = double(dat);
a = a(sum(a, 2) > 0,:);

m = row_means(a);
x = min(m):(max(m)-min(m))/20:max(m);
n = hist(m, x);


figure, hold on
col = colormap(lines(size(a,1)));
P = [];
for i=1:size(a,2)
    n1 = hist(m(a(:,i)==0), x);
    %c = (n-n1)./n;
    c = n1 ./ n;
    
    ok = (c < 1) & (c > 0);
    
    plot(x, log(c./(1-c)),'-', 'Color', col(i,:), 'MarkerSize', 10)

    p = polyfit(x(ok), log(c(ok)./(1-c(ok))), 1);
        
    P = [P; p];
    
end

set(gca, 'XLim', [min(x) max(x)])
xlabel('log mean')
ylabel('logistics transformed of misdetection rate')
set(gcf, 'Color', 'w')
%export_fig fig2c.pdf

figure, hold on
col = colormap(lines(size(a,1)));
xx = min(m):(max(m)-min(m))/1000:max(m);
for i=1:size(a,2)
    tmp = exp(xx * P(i,1) + P(i,2));
    plot(xx, tmp ./ (1+tmp), '-', 'Color', col(i,:));
end

ab = median(P);
tmp = exp(xx * ab(1) + ab(2));
plot(xx, tmp ./ (1+tmp), '-', 'Color', 'r', 'LineWidth', 4);

set(gca, 'XLim', [min(x) max(x)])
xlabel('log mean')
ylabel('\phi_{\itu}')
set(gcf, 'Color', 'w')
%export_fig fig2c2.pdf

function m = row_means(dat)

N = size(dat, 1);

m = zeros(N, 1);

for i=1:N
    x = dat(i, :);
    x = x(x>0);
    m(i) = mean(log(x));
end

