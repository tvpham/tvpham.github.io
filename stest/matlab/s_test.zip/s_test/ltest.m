function pval = ltest(g1, g2)

[muhat1, sigmahat1] = normfit(g1);
[muhat2, sigmahat2] = normfit(g2);

sigmahat = sqrt((length(g1)*var(g1,1) + length(g2)*var(g2,1))/(length(g1)+length(g2)));

L1 = normpdf(g1, muhat1, sigmahat);

L2 = normpdf(g2, muhat2, sigmahat);


[muhat, sigmahat] = normfit([g1 g2]);
sigmahat = std([g1 g2],1);
L0 = normpdf([g1 g2], muhat, sigmahat);

stat = 2*(sum(log(L1)) + sum(log(L2)) - sum(log(L0)));


if (stat < 0)
    stat = 0;
end

pval = 1 - chi2cdf(stat, 1);
