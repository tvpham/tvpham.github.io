function [ab, c] = plotme_technical_estimate(dat, cc)

[old_c, mm, ss] = estimate_cv(dat);

old_c

plot(log(mm), log(ss), '.')
xl = [min([log(mm);log(ss)]) max([log(mm);log(ss)])];
hold on, plot(xl, xl, 'r-', 'LineWidth', 2.5)

    cv = sqrt(exp(cc)-1)
    c=-log(cv)
    
    plot(xl, xl - c, 'c:', 'LineWidth', 2.5)
    plot(xl, xl + log(old_c), 'g--', 'LineWidth', 2.5)
    
axis equal, xlim(xl), ylim(xl)
set(gcf, 'Color', 'w')
xlabel('log mean')
ylabel('log standard deviation')


function [c, m, s] = estimate_cv(dat)
% dat = normalized, nonlog data

thres = size(dat, 2) / 2;
%thres = 40;

m = [];
s = [];

for i=1:size(dat,1)
    x = dat(i,:);
    if (sum(x > 0) > thres)
        x = x(x > 0);
        m = [m; mean(x)];
        s = [s; std(x, 1)];
    end
end

c = median(s ./ m);
