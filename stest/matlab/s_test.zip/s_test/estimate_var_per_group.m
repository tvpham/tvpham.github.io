function [var2, df] = estimate_var_per_group(y, techvar2, df0)

y_ok = y(y > -Inf);

if isempty(y_ok)
    var2 = techvar2;
    df = df0;    
else
    var2 = var(y_ok, 1);
    if var2 < techvar2
        var2 = techvar2;
        df = df0;
    else
        df = length(y_ok);
    end    
end



