function [log_lambda, u] = weighted_sampling_pyu(y, ab, techvar2, mu, sigma2)
% mu, sigma2 for -Inf case

[z, wz] = gh_quadrature;

if isfinite(y)            
    mu_hat = y;
    sigma2_hat = techvar2;
else
    mu_hat = mu;
    sigma2_hat = sigma2;
end
        
u = z * sqrt(2) * sigma2_hat + mu_hat;
        
log_lambda = log(sqrt(2) * sigma2_hat * wz) + log_pyu(y, u, ab, techvar2);
    

function ll = log_pyu(y, u, ab, c2)

phi =  exp(u * ab(1) + ab(2));

if isfinite(y)
    ll = -log(1 + phi) - log(sqrt(2.0 * pi * c2)) - (y - u).^2 / (2.0 * c2);
else
    ll = log(phi ./ (1.0 + phi));
end