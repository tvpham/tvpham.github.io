function ab = estimate_ab(dat)
% dat = normalized, nonlog data

N = size(dat, 1);

% calculate row means in log space
m = zeros(N, 1);
for i=1:N
    x = dat(i, :);
    x = x(x>0);
    m(i) = mean(log(x));
end


x = min(m):(max(m)-min(m))/20:max(m);
n = hist(m, x);


P = [];
for i=1:size(dat,2)
    
    n1 = hist(m(dat(:,i)==0), x);
    
    %c = (n-n1)./n;
    c = n1 ./ n;    
    ok = (c < 1) & (c > 0);        

    p = polyfit(x(ok), log(c(ok)./(1-c(ok))), 1);        
    P = [P; p];    
end

ab = median(P);
