function [L, beta] = max_LL(Lw, U, X, y, s2)

%Lw
%U

maxT = 1e4;
f_tol = 1e-8;
beta_tol = 1e-8;

[M, K] = size(U);

A = X*X' \ X;

yy = y;
yy(yy == -Inf) = mean(yy(yy > -Inf)); % for starting values

beta = A * yy';

xbeta = (X' * beta)';

L = -Inf;

for t=1:maxT
    
    %fprintf(1,'L = %f, sigma2 = %f\n', L, s2);
    %pause
        
    old_L = L;
    old_beta = beta;
        
    R2 = (U - repmat(xbeta, M, 1)).^2;
     
    H_mk = Lw - 0.5 * log(2*pi* s2) - R2 / (2 * s2);
    
    Lk = lse(H_mk);
        
    L = sum(Lk);
    
    W_mk = exp(H_mk - repmat(Lk, M, 1));
    
    v = sum(U .* W_mk, 1);
               
    beta = A * v';
    xbeta = (X' * beta)';
                       
    if (norm(old_L - L, Inf) < f_tol && norm(old_beta - beta, Inf) < beta_tol)
        break;
    end
end


function s = lse(a)

y = max(a,[], 1);

a = a - repmat(y, size(a, 1), 1); % substract the max

s = y + log(sum(exp(a), 1));
