function pval = s_test(y1, y2, techvar2, df0, ab)
% y1 = group 1, log transformed
% y2 = group 2, log transformed


y = [y1 y2];
X = [ones(1, length(y)); ones(1, length(y1)) ones(1, length(y2)) + 1];

y_ok = y(y > -Inf);

if isempty(y_ok)
    pval = 1.0;
    return;
end

[sigma2, ~] = estimate_var_per_group(y, techvar2, df0);

% for -Inf case

%null_mu = mean(y_ok);
%null_mu = min(y_ok); % - sqrt(techvar2);

%null_sigma2 = sigma2 * 4; % sampling variance = 2 x std
%null_sigma2 = sigma2;

% option 1
% null_mu = min(y_ok) / 2;
% null_sigma2 = sigma2;

% option 2
null_mu = min(y_ok);
null_sigma2 = techvar2;

% ----- simulate 
Lw = [];
U = [];

for k = 1:length(y)
    [log_lambda, u] = weighted_sampling_pyu(y(k), ab, techvar2, null_mu, null_sigma2);
    Lw = [Lw log_lambda];
    U = [U u];
end



% ----- unrestricted MLE

[var2_1, df1] = estimate_var_per_group(y1, techvar2, df0);
[var2_2, df2] = estimate_var_per_group(y2, techvar2, df0);

sigma2_hat = (df1 * var2_1 + df2 * var2_2)/(df1 + df2);

[uLogL, ~] = max_LL(Lw, U, X, y, sigma2_hat);

% ----- restrictied MLE
[rLogL, ~] = max_LL(Lw, U, X(1,:), y, sigma2_hat);

%[h, pValue, stat] = lratiotest(uLogL, rLogL, 1);

stat = 2 * (uLogL - rLogL);

if (stat < 0)
    stat = 0;
end

%stat

pval = 1 - chi2cdf(stat, 1);
