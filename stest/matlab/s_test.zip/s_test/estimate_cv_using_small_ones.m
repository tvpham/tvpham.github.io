function [c, m, s] = estimate_cv_using_small_ones(dat)
% dat = normalized, nonlog data

thres = size(dat, 2) / 2;

m = [];
s = [];

for i=1:size(dat,1)
    x = dat(i,:);
    if (sum(x > 0) > thres)
        x = x(x > 0);
        m = [m; mean(x)];
        s = [s; std(x)];
    end
end

tmp = sort(s ./ m);
c = median(tmp(1:100));
