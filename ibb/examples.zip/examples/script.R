
library(ibb)

# three-group comparison

d <- read.delim("example-3groups.txt", header = TRUE)


# using all available CPU cores

out <- bb.test(d[, 1:8], colSums(d[, 1:8]), c(rep("a", 3), rep("b", 3), rep("c", 2)), n.threads = 0)


# write result to file

write.table(cbind(d, out$p.value), file = "example-3groups-out.tsv" , sep =
"\t", row.names = FALSE)

#####################################

# paired test

d <- read.delim("example-paired.txt", header = TRUE)


# perform a paired test for all rows, using all but one CPU cores

out <- ibb.test(d[, 1:6], colSums(d[, 1:6]), c(rep("pre", 3), rep("post", 3)), n.threads = -1)

# write result to file

write.table(cbind(d, out$fc, out$p.value), file = "example-paired-out.txt", sep = "\t", row.names = FALSE)
